package com.capacitorjs.plugins.nativeislands

import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import io.ionic.libs.ionnativeislandslib.NativeIslandsBridgeValidationError
import io.ionic.libs.ionnativeislandslib.NativeIslandsBridgeValidator
import io.ionic.libs.ionnativeislandslib.NativeIslandsController
import androidx.lifecycle.Lifecycle
import org.json.JSONArray
import org.json.JSONObject

/** Capacitor marshalling shell for the shared Native Islands controller. */
@CapacitorPlugin(name = "NativeIslands")
class NativeIslandsPlugin : Plugin() {

    private val controller by lazy {
        NativeIslandsController { event, payload ->
            notifyListeners(event, JSObject.fromJSONObject(payload))
        }
    }

    override fun load() {
        controller.bind(bridge.webView, activity)
        activity.runOnUiThread {
            controller.ensureContainer()
            if (activity.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) {
                controller.onHostResume()
            } else {
                controller.onHostPause()
            }
        }
    }

    @PluginMethod
    fun applyLayout(call: PluginCall) {
        val envelope = call.data
        if (!validate(call, NativeIslandsBridgeValidator.validateLayoutOperation(envelope))) {
            return
        }
        controller.bind(bridge.webView, activity)
        val components = envelope.opt("components") as JSONArray
        val order = envelope.opt("order") as JSONArray
        val exclusions = envelope.opt("exclusions") as JSONObject
        controller.validateLayout(components, order, exclusions)?.let { reason ->
            call.reject(reason, "invalid_request")
            return
        }
        controller.applyLayout(
            components,
            order,
            exclusions,
            failure = { code, message -> call.reject(message, code) },
        ) { call.resolve() }
    }

    @PluginMethod
    fun command(call: PluginCall) {
        val envelope = call.data
        if (!validate(call, NativeIslandsBridgeValidator.validateCommandOperation(envelope))) {
            return
        }
        val version = (envelope.opt("protocolVersion") as Number).toInt()
        val island = envelope.opt("island") as String
        val component = envelope.opt("islandType") as String
        val method = envelope.opt("method") as String
        val params = envelope.opt("params") as? JSONObject ?: JSONObject()
        controller.dispatchCommand(
            version,
            island,
            component,
            method,
            NativeIslandsJson.objectToMap(params),
        ) { result ->
            val code = result.optString("code")
            if (code.isNotEmpty()) {
                call.reject(result.optString("error", code), code)
            } else {
                call.resolve()
            }
        }
    }

    @PluginMethod
    fun reset(call: PluginCall) {
        if (
            !validate(
                call,
                NativeIslandsBridgeValidator.validateOperation("reset", call.data),
            )
        ) {
            return
        }
        controller.reset()
        call.resolve()
    }

    override fun handleOnResume() = controller.onHostResume()

    override fun handleOnPause() = controller.onHostPause()

    override fun handleOnDestroy() = controller.dispose()

    private fun validate(
        call: PluginCall,
        error: NativeIslandsBridgeValidationError?,
    ): Boolean =
        if (error == null) {
            true
        } else {
            call.reject(error.message, error.code)
            false
        }

}

internal object NativeIslandsJson {
    fun objectToMap(value: JSONObject): Map<String, Any?> {
        val result = HashMap<String, Any?>()
        val keys = value.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            result[key] = normalize(value.opt(key))
        }
        return result
    }

    private fun normalize(value: Any?): Any? = when (value) {
        null, JSONObject.NULL -> null
        is JSONObject -> objectToMap(value)
        is JSONArray -> List(value.length()) { index ->
            normalize(value.opt(index))
        }
        else -> value
    }
}
