# @capacitor/native-islands

Native Islands is a Capacitor plugin for placing app-owned native views inside a web
document while preserving document scroll, CSS stacking, and touch ownership. It is
additive: an existing Capacitor app defines only the native components it needs, and
the same custom elements render required web fallbacks outside a native build.

This package contains the composition runtime and Capacitor bridge. It does not
ship a component library, demo component, renderer engine, or Capacitor fork.

## Install

```sh
npm install @capacitor/native-islands
npx cap sync
```

No Native Islands block is required in `capacitor.config`.

Component plugins can include Native Islands and register their own native views. In
that model, an application installs only the component plugin and uses its custom
elements. Applications that define native components directly use the APIs below.

## Define a component

```ts
import { defineNativeIsland } from '@capacitor/native-islands';

defineNativeIsland({
  tagName: 'acme-map',
  nativeComponent: 'acme.map',
  isInteractive: true,
  observedAttributes: ['latitude', 'longitude'],
  getProperties: (element) => ({
    latitude: Number(element.getAttribute('latitude')),
    longitude: Number(element.getAttribute('longitude')),
  }),
  renderFallback: (element) => {
    element.textContent = 'Map unavailable';
  },
  events: {
    cameraChanged: 'camerachanged',
  },
});
```

```html
<acme-map
  latitude="41.1579"
  longitude="-8.6291"
  style="display:block;height:280px;border-radius:24px;z-index:2"
></acme-map>
```

The runtime sends `create` when the element connects and `update` when observed
attributes change. Attribute changes in the same task are coalesced into one update.
Those are the only component commands. A rejected mount changes that element to its
web fallback rather than leaving an empty composition region.

Component plugins can also list resolved CSS properties in `observedStyles`.
Changes caused by inline styles, classes, inherited custom properties, stylesheets,
or common system appearance preferences are coalesced into `update`. Read those
values with `getComputedStyle(element)` inside `getProperties`.

Observed attributes also expose reflected string properties when the name does not
collide with a built-in element property. This means framework property binding such
as `element.label = value` or Angular `[label]="value"` reaches the same attribute
contract. `null` and `undefined` remove the attribute; convert numbers, booleans, and
structured values in `getProperties`.

Framework DOM reparenting in the same task preserves the native identity and does not
send `create` again. An element rendered before its consuming plugin's native carrier
is ready remains on fallback, then activates once when the carrier initializes.

`renderFallback` is required. The callback should be idempotent, derive its complete
output from the element it receives, and avoid closing over the custom-element
instance. The runtime calls it on browser mount, after native failure, and after an
observed attribute changes while fallback is active.

Accessibility is web-owned by default. While native composition is active, the
runtime calls `renderFallback` with a visually hidden semantic container and hides
the native subtree from accessibility. If a component instead registers its native
factory with native accessibility, set `accessibility: 'native'` in the web
definition too. The web and native registrations must agree so only one
representation is exposed to assistive technologies.

Optional definition values have these defaults:

| Option                      | Default                  |
| --------------------------- | ------------------------ |
| `isInteractive`             | `false`                  |
| `accessibility`             | `'web'`                  |
| `requiresUnobscuredSurface` | `false`                  |
| `observedAttributes`        | `[]`                     |
| `observedStyles`            | `[]`                     |
| `getProperties`             | No native properties     |
| `events`                    | No native-event mappings |

Use lowercase kebab-case for custom-element tags, HTML attributes, and DOM event
names. Convert attributes to camelCase only in the JavaScript/native property object.
Native registry names use a stable dotted namespace such as `acme.map`.

## Register the native factory

Register the same `nativeComponent` before the page mounts it.

```swift
NativeIslandsRegistry.register(componentName: "acme.map") {
    AcmeMapIsland()
}
```

```kotlin
NativeIslandsRegistry.register(componentName = "acme.map") { context, _ ->
    AcmeMapIsland(context)
}
```

Native components implement the platform `NativeIsland` interface. The controller
calls `create(properties)` once mounted and `update(properties)` for later observed
attribute changes.

## Web layers and z-index

Native Islands follows the browser's stacking contexts and `z-index`. Application
authors use ordinary HTML and CSS; they do not declare native/web layers or call a
stacking API.

The runtime automatically recognizes bounded elements whose computed background
fully covers their border box. It compares those surfaces with each island in the
browser's real paint order and sends only the intersections that need native visual
or touch cutouts.

```html
<div style="position:relative;height:300px">
  <div aria-hidden="true" style="position:absolute;inset:0;z-index:1;background:#eef2f7"></div>
  <acme-map style="position:absolute;inset:20px;z-index:2"></acme-map>
  <button style="position:absolute;right:36px;bottom:36px;z-index:3">Recenter</button>
</div>
```

For an advanced component integration, `data-native-islands-opaque-surface` can
confirm that a bounded surface the browser cannot classify, such as a fully opaque
image, is safe to treat as opaque. It does not change paint order. Ordinary app
screens should not need it. When a composition cannot be represented without losing
pixels, only the affected component uses its web fallback.

Component plugins set `requiresUnobscuredSurface: true` for protected system
surfaces that the application compositor cannot clip. If another surface is meant
to paint above one of these components, Native Islands uses its web fallback until
the overlap clears. Application authors do not manage this policy.

## Opaque shape

A uniform pixel CSS `border-radius` on the custom element is detected automatically,
sent to native, and used for both clipping and touch routing. Component users do not
need a separate radius property, and no radius is required for a rectangular element.
Non-uniform, elliptical, percentage-based, or disconnected shapes use the web
fallback in the initial release.

## Scroll and touch boundary

Document scrolling is observed and applied natively. Island document coordinates
cross the bridge only after real layout changes.

Independent `overflow: auto` and `overflow: scroll` ancestors are also modeled,
including nested containers and the inner scroller used by standard Ionic
`ion-content`. iOS observes matched native child scroll views. On Android, the
component's web fallback rides the web compositor during inner-scroll motion and the
live native component returns after one settled offset. No application scroll
handler, marker, or frame-by-frame bridge traffic is required.

Fixed islands and fixed web controls participate in the same paint-order plan.
Axis-aligned translation is supported. Sticky islands, CSS zoom,
scale/rotation/skew/perspective, filters, blending or partial opacity on an island,
and complex authored clipping use the web fallback. The native component returns
when the unsupported style is removed.

Set `isInteractive: true` when the native component owns gestures that begin in its
visible region. A composed web surface above it keeps ownership of touches in its overlap.
Touch ownership does not change during a gesture. `pointer-events: none` or an
`inert` composed ancestor prevents a new native gesture from starting.

## Framework integration

Native Islands has one standards-based custom-element runtime rather than separate
React, Angular, Vue, Astro, or Ionic implementations.

- React 19 and Vanilla JavaScript can import the element definition directly. Add a
  JSX intrinsic-element declaration for TypeScript component packages.
- Angular templates add `CUSTOM_ELEMENTS_SCHEMA`. Observed property bindings reflect
  to attributes; register the element only in browser code when using SSR.
- Vue configures `compilerOptions.isCustomElement` for the component tag.
- Astro loads the definition from a client `<script>`; server frontmatter cannot call
  `customElements.define`.
- Ionic supports document scrolling, inline `ion-content`, and `slot="fixed"`
  placement.

Open shadow roots and slotted islands are supported. A component that owns a closed
shadow root must expose an overlapping opaque surface through its host, because the
browser does not let Native Islands inspect the closed tree.

## Public API

The root package exports only:

- `defineNativeIsland(options)`
- `DefineNativeIslandOptions`

`@capacitor/native-islands/internal` is reserved for bridge packages that initialize
the same runtime with another transport. Separately bundled consuming plugins share
one page-wide runtime and registry, so application authors do not coordinate them.
Application code should not import the internal entry.

## Requirements

- `@capacitor/core >=8.4.1 <9`
- iOS 15 or newer
- Android API 24 or newer
- A modern browser for the web fallback

The fixture app covers app-owned registration, fallback rendering, document scrolling,
z-index re-stacking, and touch ownership. Simulator and emulator runs verify
correctness and packaging; performance and hardware claims require physical devices.

## License

MIT
