# @capacitor/native-islands

Native Islands is a Capacitor plugin for placing app-owned native views inside a web
document while preserving document scroll, CSS stacking, and touch ownership. It is
additive: an existing Capacitor app defines only the native components it needs, and
the same custom elements render required web fallbacks outside a native build.

This package contains the composition runtime and thin Capacitor wrappers. It does not
ship a component library, demo component, renderer engine, or Capacitor fork.

## Install

```sh
npm install @capacitor/native-islands
npx cap sync
```

No Native Islands block is required in `capacitor.config`.

The repository currently uses local native-library dependencies while those libraries
remain unpublished. Keep the local Swift package path and Android AAR for development;
do not publish this package until those references are replaced with released
dependencies.

Component plugins can consume the Native Islands web runtime and native libraries,
provide the bridge carrier, and perform both the web definition and native
registration themselves. This does not rely on Capacitor discovering a nested Native
Islands package as a separate plugin. In that model, an application installs only
the component plugin and uses its custom element:

```html
<os-location-button></os-location-button>
```

Application authors do not import Native Islands, register a factory, add Capacitor
configuration, or pass a separate radius property. The following definition and
factory sections are for component-plugin authors and apps that intentionally own
their native component.

## Define a component

```ts
import { defineNativeIsland } from '@capacitor/native-islands';

defineNativeIsland({
  tagName: 'acme-map',
  nativeComponent: 'acme.map',
  isInteractive: true,
  observedAttributes: ['latitude', 'longitude'],
  getProperties: (element) => ({
    latitude: Number(element.getAttribute('latitude')),
    longitude: Number(element.getAttribute('longitude')),
  }),
  renderFallback: (element) => {
    element.textContent = 'Map unavailable';
  },
  events: {
    cameraChanged: 'camerachanged',
  },
});
```

```html
<acme-map
  latitude="41.1579"
  longitude="-8.6291"
  style="display:block;height:280px;border-radius:24px;z-index:2"
></acme-map>
```

The runtime sends `create` when the element connects and `update` when observed
attributes change. Attribute changes in the same task are coalesced into one update.
Those are the only component commands. A rejected mount changes that element to its
web fallback rather than leaving an empty composition region.

Observed attributes also expose reflected string properties when the name does not
collide with a built-in element property. This means framework property binding such
as `element.label = value` or Angular `[label]="value"` reaches the same attribute
contract. `null` and `undefined` remove the attribute; convert numbers, booleans, and
structured values in `getProperties`.

Framework DOM reparenting in the same task preserves the native identity and does not
send `create` again. An element rendered before its consuming plugin's native carrier
is ready remains on fallback, then activates once when the carrier initializes.

`renderFallback` is required. The callback should be idempotent, derive its complete
output from the element it receives, and avoid closing over the custom-element
instance. The runtime calls it on browser mount, after native failure, and after an
observed attribute changes while fallback is active.

Accessibility is web-owned by default. While native composition is active, the
runtime calls `renderFallback` with a visually hidden semantic container and hides
the native subtree from accessibility. If a component instead registers its native
factory with native accessibility, set `accessibility: 'native'` in the web
definition too. The web and native registrations must agree so only one
accessibility face exists.

Optional definition values have these defaults:

| Option               | Default                  |
| -------------------- | ------------------------ |
| `isInteractive`      | `false`                  |
| `accessibility`      | `'web'`                  |
| `observedAttributes` | `[]`                     |
| `getProperties`      | No native properties     |
| `events`             | No native-event mappings |

Use lowercase kebab-case for custom-element tags, HTML attributes, and DOM event
names. Convert attributes to camelCase only in the JavaScript/native property object.
Native registry names use a stable dotted namespace such as `acme.map`.

## Register the native factory

Register the same `nativeComponent` before the page mounts it.

```swift
NativeIslandsRegistry.register(componentName: "acme.map") {
    AcmeMapIsland()
}
```

```kotlin
NativeIslandsRegistry.register(componentName = "acme.map") { context, _ ->
    AcmeMapIsland(context)
}
```

Native components implement the platform `NativeIsland` interface. The controller
calls `create(properties)` once mounted and `update(properties)` for later observed
attribute changes.

## Web layers and z-index

Web content that can overlap an island must carry the canonical
`data-native-islands-layer` attribute. This lets the runtime compute the matching
knockout and touch exclusion. The browser's actual stacking contexts and `z-index`
decide which side paints on top.

```html
<div style="position:relative;height:300px">
  <div
    data-native-islands-layer
    aria-hidden="true"
    style="position:absolute;inset:0;z-index:1;background:#eef2f7"
  ></div>
  <acme-map style="position:absolute;inset:20px;z-index:2"></acme-map>
  <button data-native-islands-layer style="position:absolute;right:36px;bottom:36px;z-index:3">Recenter</button>
</div>
```

Unmarked overlapping web content is outside the composition contract and may cover a
native surface incorrectly. Mark every potentially overlapping web layer, or keep it
outside the island's bounds.

A marked layer is an atomic, locally bounded web surface. Its visible paint must stay
inside its declared box. Box shadows, outlines, filters, visible overflow, and other
paint that escapes that box use the web fallback rather than risking an incorrect
knockout. Do not mark a large opaque ancestor and expect arbitrary descendants to be
split around an island; declare the smaller overlapping surface itself.

A marked web layer must not define its own CSS `clip-path`; the runtime cannot combine
an arbitrary authored clip with the native knockout. If they overlap, the island uses
its web fallback and the authored clip is preserved. Removing the unsupported clip
restores the existing native component. Runtime knockout holes are opened only after
native acknowledges the corresponding layout, avoiding a blank hole during delayed
mount or re-stack.

## Opaque shape

A uniform pixel CSS `border-radius` on the custom element is detected automatically,
sent to native, and used for both clipping and touch routing. Component users do not
need a separate radius property, and no radius is required for a rectangular element.
Non-uniform, elliptical, percentage-based, or disconnected shapes use the web
fallback in the initial release.

## Scroll and touch boundary

Document scroll is the supported launch path. Island document coordinates cross the
bridge only after real layout changes; ordinary page scrolling is observed and applied
natively.

Independent `overflow: auto` or `overflow: scroll` ancestors, including scroll
containers inside a shadow tree, are not supported in the initial release. An island
inside one falls back to web instead of drifting. Use document scrolling for native
islands. This includes the inner scroller used by standard Ionic `ion-content`.

`visibility: hidden` and zero opacity deactivate the native surface. Fixed/sticky
positioning, CSS zoom, matrix scaling, rotation, skew, perspective, motion paths,
three-dimensional translation, masks, paint containment, bordered or partial
overflow clipping, and non-default clip margins use the web fallback. Individual CSS
scale/rotation, partial opacity, filters, backdrop filters, and blend modes on the
island or a composed ancestor also use the web fallback. Axis-aligned translation is
supported. These are recoverable states: route transitions and layout-affecting CSS
animations show the functional fallback while active and resume the same native
component afterward instead of permanently degrading it. Paint-only animation that
cannot alter geometry or composition remains native.

Set `isInteractive: true` when the native component owns gestures that begin in its
visible region. A marked web layer above it keeps ownership of touches in its overlap.
Touch ownership does not change during a gesture. `pointer-events: none` or an
`inert` composed ancestor prevents a new native gesture from starting.

## Framework integration

Native Islands has one standards-based custom-element runtime rather than separate
React, Angular, Vue, Astro, or Ionic implementations.

- React 19 and Vanilla JavaScript can import the element definition directly. Add a
  JSX intrinsic-element declaration for TypeScript component packages.
- Angular templates add `CUSTOM_ELEMENTS_SCHEMA`. Observed property bindings reflect
  to attributes; register the element only in browser code when using SSR.
- Vue configures `compilerOptions.isCustomElement` for the component tag.
- Astro loads the definition from a client `<script>`; server frontmatter cannot call
  `customElements.define`.
- In Ionic, use document scrolling or `slot="fixed"`. An island in the standard
  inline `ion-content` shadow scroller intentionally falls back because following
  that private DOM scroll would require forbidden per-frame bridge traffic.

Open shadow roots and slotted islands are observed. A marked layer inside an open
shadow root is discovered; an unrelated closed root must declare its host as the web
layer because browser encapsulation makes its internals unavailable. Closed-shadow
internal reflow and stylesheet mutations that do not resize an observed node are not
observable through public DOM APIs; the component host must own or expose the relevant
surface.

## Public API

The root package exports only:

- `defineNativeIsland(options)`
- `DefineNativeIslandOptions`

`@capacitor/native-islands/internal` is reserved for bridge packages that initialize
the same runtime with another transport. Separately bundled consuming plugins share
one page-wide runtime and registry, so application authors do not coordinate them.
Application code should not import the internal entry.

## Requirements

- Capacitor 8.4.1 or newer, before Capacitor 9
- iOS 15 or newer
- Android API 24 or newer
- A modern browser for the web fallback

The fixture app covers app-owned registration, fallback rendering, document scrolling,
z-index re-stacking, and touch ownership. Simulator and emulator runs verify
correctness and packaging; performance and hardware claims require physical devices.

## License

MIT
